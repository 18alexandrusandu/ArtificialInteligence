#./Conformant-FF -o cff-tests/block/domain -f cff-tests/block/p2-13-0.pddl

#./Contingent-FF -o contff-tests/blocks/domain.pddl -f contff-tests/blocks/p1.pddl

